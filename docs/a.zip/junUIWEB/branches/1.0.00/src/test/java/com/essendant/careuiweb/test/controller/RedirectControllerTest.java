package com.essendant.careuiweb.test.controller;

import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.essendant.careuiweb.configuration.CareUIConfiguration;
import com.essendant.careuiweb.configuration.CoreConfiguration;
import com.essendant.careuiweb.test.config.TestConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {CareUIConfiguration.class, CoreConfiguration.class, TestConfiguration.class/*, CachingConfiguration.class*/})
@WebAppConfiguration
@TestPropertySource(value = {"classpath:environment.properties", "classpath:com/essendant/careuiweb/props/appConfigTest.properties"})
public class RedirectControllerTest {

	@Autowired
	private WebApplicationContext context;
	
	private MockMvc mockMvc;
	
	@Autowired
	private Environment environment;

	@Before
	public void setup() {
		
//		System.out.println(environment.getProperty("com.essendant.careuiweb.config.hostname.empower"));
//		System.out.println(environment.getProperty("com.essendant.careuiweb.config.hostname.local"));
//		System.out.println(environment.getProperty("com.essendant.smartsearch.service.userid"));
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.context).build();
	}
	
	@Test
	public void tst() {
		assertTrue(true);
	}
	
	@Test
	public void testServiceTest() throws Exception {
		MvcResult result =  mockMvc.perform(get("/v1/test").accept(MediaType.TEXT_PLAIN)).andReturn();
		mockMvc.perform(get("/v1/test"))
		.andExpect(status().isOk());
	}
	
	@Test
	public void testRedirectTest() throws Exception {
		mockMvc.perform(get("/v1/redirect"))
				.andExpect(status().isFound());
	}
	
	@Test
	public void redirectToEmpowerTest() throws Exception {
		mockMvc.perform(post("/v1/redirectEmpower"))
				.andExpect(status().isFound());
	}
	
	@Test
	public void testRedirectWithParamsTest() throws Exception {
		mockMvc.perform(get("/v1/redirectWith"))
				.andExpect(status().isFound());
	}
	
	@Test
	public void redirectToEmpowerWithParamsTest() throws Exception {
		String json = "{\"accountId\": \"000005\",\"orderId\": \"4444\",\"page\": \"http://10.250.24.218:9081/careweb/v1/test\",\"params\": [],\"userId\": \"superusertest\"}";
		mockMvc.perform(post("/v1/redirectEmpowerWith").contentType(MediaType.APPLICATION_JSON).content(json))
				.andExpect(status().isFound());
	}
	
}
