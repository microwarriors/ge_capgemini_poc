package com.essendant.careuiweb.test.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.DelegatingWebMvcConfiguration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.essendant.careuiweb.controller.RedirectController;
import com.essendant.careuiweb.utils.ApiVersionRequestMappingHandlerMapping;
import com.essendant.careuiweb.utils.RequestObject;

@Configuration
//@ContextConfiguration(locations={"classpath:environment.properties"})
public class TestConfiguration {
	
	@Bean
	public RedirectController redirectController() {
		return new RedirectController();
	}
	
	@Bean
	public RequestObject requestObject() {
		return new RequestObject();
	}

}