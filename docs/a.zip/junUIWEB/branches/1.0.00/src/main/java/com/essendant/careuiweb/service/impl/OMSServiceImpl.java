package com.essendant.careuiweb.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.essendant.careuiweb.configuration.LoggingServiceInterface;
import com.essendant.careuiweb.service.OMSService;

@Scope("prototype")
@Service
public class OMSServiceImpl implements OMSService {
	@Autowired
	LoggingServiceInterface loggingService;	

	@Override
	public void createOrder(String account, String poNumber) {	
		
	}

	@Override
	public void updateOrder(String orderId) {
		
		
	}

	@Override
	public void cancelOrder(String orderId) {
		
		
	}

	@Override
	public void createOrderLine(String orderId, String itemNumber, String quantity) {
		
		
	}

	@Override
	public void updateOrderLine(String orderId, String itemNumber, String quantity) {
		
		
	}

	@Override
	public void cancelOrderLine(String orderId) {
		
		
	}

	@Override
	public void lookupOrder(String orderId) {
		
		
	}

	@Override
	public void lookupAccountInformation(String accountNumber) {
		
		
	}

	@Override
	public void lookupItemPricing(String itemNumber) {
		
		
	}

	@Override
	public void lookupItemStock(String itemNumber) {
		
		
	}


}
