package com.essendant.careuiweb.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.essendant.careuiweb.annotations.ApiVersion;
import com.essendant.careuiweb.businessobjects.Menu;
import com.essendant.careuiweb.configuration.LoggingServiceInterface;
import com.essendant.careuiweb.consts.Version;
import com.essendant.careuiweb.service.MenuNavigationService;
import com.google.gson.Gson;
import com.ussco.ajax.ProductMenu;
import com.ussco.ajax.ProductMenuCategory;

@RestController
@ApiVersion(Version.ONE)
public class NavMenuController {
	@Autowired
	LoggingServiceInterface loggingService;	
	
	@Autowired
	MenuNavigationService menuNavigationService;
	
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public ResponseEntity<?> getHeader() {
		Gson gson = new Gson();
		Map<String, Map<String, Menu>> headerMockMap = new HashMap<String, Map<String, Menu>>();
		
		// build mock header
		headerMockMap.put("Products", menuNavigationService.buildMockProductMenu());
		headerMockMap.put("OrderInvoice", menuNavigationService.buildMockOrderInvoiceMenu());
		headerMockMap.put("Returns", menuNavigationService.buildMockReturnCreditMenu());
		headerMockMap.put("Customer", menuNavigationService.buildMockCustomerMenu());
		headerMockMap.put("Account", menuNavigationService.buildMockAccountMenu());		
		headerMockMap.put("Dashboard", menuNavigationService.buildMockDashboardMenu());
		headerMockMap.put("Footer", menuNavigationService.buildMockFooterURL());
		return new ResponseEntity(gson.toJson(headerMockMap), HttpStatus.FOUND);		
	}
	
	@RequestMapping(value="/header", method=RequestMethod.GET)
	public ResponseEntity<?> getHeaderFooter() {
		Gson gson = new Gson();
		Map<String, ProductMenu> headerMap = new HashMap<String, ProductMenu>();
		
		headerMap.put("Products", menuNavigationService.buildProductMenu());
		headerMap.put("OrderInvoice", menuNavigationService.buildOrderInvoiceMenu());
		headerMap.put("Returns", menuNavigationService.buildReturnCreditMenu());
		headerMap.put("Customer", menuNavigationService.buildCustomerMenu());
		headerMap.put("Account", menuNavigationService.buildAccountMenu());		
		headerMap.put("Dashboard", menuNavigationService.buildDashboardMenu());
		headerMap.put("Footer", menuNavigationService.buildFooterURL());
		return new ResponseEntity(gson.toJson(headerMap), HttpStatus.FOUND);
	}	
	
//	@RequestMapping(value="/menu/product", method=RequestMethod.GET)
//	public ResponseEntity<?> getProductMenu() {
//		String menu = null;
//		
//		menu = menuNavigationService.buildProductMenu(null);
//		return new ResponseEntity(menu, HttpStatus.FOUND);
//	}
	
//	@RequestMapping(value="/menu/orderinvoice", method=RequestMethod.GET)
//	public ResponseEntity<?> getOrderInvoiceMenu() {
//		String menu = null;
//		
//		menu = menuNavigationService.buildOrderInvoiceMenu();
//		return new ResponseEntity(menu, HttpStatus.FOUND);
//	}

//	@RequestMapping(value="/menu/customer", method=RequestMethod.GET)
//	public ResponseEntity<?> getCustomerMenu() {
//		String menu = null;
//		
//		menu = menuNavigationService.buildCustomerMenu();
//		return new ResponseEntity(menu, HttpStatus.FOUND);		
//	}
	
//	@RequestMapping(value="/menu/returncredit", method=RequestMethod.GET)
//	public ResponseEntity<?> getReturnCreditMenu() {
//		String menu = null;
//		
//		menu = menuNavigationService.buildReturnCreditMenu();
//		return new ResponseEntity(menu, HttpStatus.FOUND);
//	}
	
//	@RequestMapping(value="/menu/account", method=RequestMethod.GET)
//	public ResponseEntity<?> getAccountMenu() {
//		String menu = null;
//		
//		menu = menuNavigationService.buildAccountMenu();
//		return new ResponseEntity(menu, HttpStatus.FOUND);
//	}
		

//	@RequestMapping(value="/menu/dashboard", method=RequestMethod.GET)
//	public ResponseEntity<?> getDashboardMenu() {
//		String menu = null;
//		
//		menu = menuNavigationService.buildDashboardMenu();
//		return new ResponseEntity(menu, HttpStatus.FOUND);
//	}
	
//	@RequestMapping(value="/footer")
//	public ResponseEntity<?> getFooterURL() {
//		String response = null;
//		
//		loggingService.performLogging("DEBUG", "NavMenuController:getFooterURL CareUIRuntime.SOLUTIONCENTRAL_URL = " + CareUIRuntime.SOLUTIONCENTRAL_URL, null);
//		response = CareUIRuntime.SOLUTIONCENTRAL_URL;
//		return new ResponseEntity(response, HttpStatus.FOUND);
//	}	
}
