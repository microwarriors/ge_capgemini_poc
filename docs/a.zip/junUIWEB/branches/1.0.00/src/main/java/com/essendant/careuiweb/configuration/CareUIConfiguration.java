package com.essendant.careuiweb.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.essendant.careuiweb.consts.Version;
import com.essendant.careuiweb.utils.ApiVersionRequestMappingHandlerMapping;
import com.ussco.pagebuilder.entity.RequestConfig;
import com.ussco.pagebuilder.entity.impl.RequestConfigImpl;
import com.ussco.profile.entity.impl.controller.CustomerImplManager;
import com.ussco.profile.service.AccountService;
import com.ussco.profile.service.CustomerService;
import com.ussco.profile.service.CustomerSubscriptionService;
import com.ussco.profile.service.FacilityService;
import com.ussco.profile.service.impl.AccountWorker;
import com.ussco.profile.service.impl.CustomerServiceImpl;
import com.ussco.profile.service.impl.ESBCustomerSubscriptionServiceImpl;
import com.ussco.profile.service.impl.FacilityServiceImpl;
import com.ussco.profile.service.impl.UsscoAccountServiceImpl;
import com.ussco.web.ajax.service.ProductMenuOptionService;
import com.ussco.web.ajax.service.impl.ProductMenuOptionServiceImpl;
import com.ussco.web.service.ItemSearchService;
import com.ussco.web.service.impl.SmartSearchItemSearchService;
import com.ussco.xml.ws.spring.factory.AccountInformationInterfaceFactory;
import com.ussco.xml.ws.spring.factory.CustomerSubscriptionInterfaceFactory;
import com.ussco.xml.ws.spring.factory.ECatalogInterfaceFactory;
import com.ussco.xml.ws.spring.factory.PricingAndAvailabilityInterfaceFactory;

//CareUI Configuration class will contain configuration for application that should be done during startup
@Configuration
@ImportResource({ "classpath:com/essendant/careuiweb/jpaconfig/profile-jpa-config.xml"})
public class CareUIConfiguration extends WebMvcConfigurationSupport {

	@Autowired
	private CoreConfiguration coreConfiguration;

//	@Autowired
//	private CachingConfiguration cachingConfiguration;

	@Autowired
	private Log4jConfiguration log4jConfiguration;
	
	public CareUIConfiguration() {

	}

	@Override
	public RequestMappingHandlerMapping requestMappingHandlerMapping() {
		RequestMappingHandlerMapping handlerMapping = new ApiVersionRequestMappingHandlerMapping(Version.PREFIX);
		handlerMapping.setOrder(0);
		handlerMapping.setInterceptors(getInterceptors());
		return handlerMapping;
	}

	@Bean ProductMenuOptionService productMenuOptionService() {
		return new ProductMenuOptionServiceImpl();
	}
	
	@Bean RequestConfig operationsRequestConfig() {
		RequestConfig requestConfig = new RequestConfigImpl();
		
		requestConfig.setHost(System.getProperty("com.ussco.config.operations.hostname"));
		requestConfig.setContextPath(System.getProperty("com.ussco.config.operations.contextPath "));
		requestConfig.setScheme(System.getProperty("com.ussco.config.operations.scheme"));
		return requestConfig;
	}	
	
	@Bean ECatalogInterfaceFactory smartSearchInterface() {
		return new ECatalogInterfaceFactory();
	}
	
	@Bean PricingAndAvailabilityInterfaceFactory pricingAndAvailabilityInterface() {
		return new PricingAndAvailabilityInterfaceFactory();
	}
	
	@Bean ItemSearchService usscoItemSearchService() {
		return new SmartSearchItemSearchService();
	}
	
//	@Bean AccountWorker accountWorker() {
//		return new AccountWorker();
//	}
	
//	@Bean AccountService accountService() {
//		return new UsscoAccountServiceImpl();
//	}
	
	@Bean AccountInformationInterfaceFactory accountInformationInterface() {
		return new AccountInformationInterfaceFactory();
	}
	
	@Bean CustomerSubscriptionService customerSubscriptionService() {
		return new ESBCustomerSubscriptionServiceImpl();
	}

	@Bean CustomerSubscriptionInterfaceFactory customerSubscriptionInterface() {
		return new CustomerSubscriptionInterfaceFactory();
	}
	
//	@Bean CustomerService customerService() {
//		return new CustomerServiceImpl();
//	}	
//	
//	@Bean FacilityService facilityService() {
//		return new FacilityServiceImpl();
//	}
	
	@Bean CustomerImplManager customerImplManager() {
			return new CustomerImplManager();
	}
	
	@Bean JndiObjectFactoryBean edithDataSource() {
		JndiObjectFactoryBean datasource = new JndiObjectFactoryBean();
		
		datasource.setJndiName("jdbc/edith/db2");
		datasource.setLookupOnStartup(true);
		datasource.setCache(true);
		datasource.setProxyInterface(javax.sql.DataSource.class);
		return datasource;
	}

}
