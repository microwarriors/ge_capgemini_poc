package com.essendant.careuiweb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.essendant.careuiweb.annotations.ApiVersion;
import com.essendant.careuiweb.configuration.LoggingServiceInterface;
import com.essendant.careuiweb.consts.Version;
import com.google.gson.Gson;

@RestController
@ApiVersion(Version.ONE)
public class LoggingController {
@Autowired
LoggingServiceInterface loggingService;

@RequestMapping(value="/log", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE) 
public ResponseEntity<?> produceLoggingPost(@RequestParam(value="level", defaultValue="") String loggingLevel, @RequestParam(value="message", defaultValue="") String message) { 
	try {
		loggingService.performLogging(loggingLevel, message, null);	
		return new ResponseEntity("Success", HttpStatus.FOUND);
	} catch (Exception e) {
		return new ResponseEntity("Failed", HttpStatus.FOUND);
	}
}

@RequestMapping(value="/log", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE) 
public ResponseEntity<?> produceLoggingGet(@RequestParam(value="level", defaultValue="") String loggingLevel, @RequestParam(value="message", defaultValue="") String message) {
	try {
		loggingService.performLogging(loggingLevel, message, null);	
		return new ResponseEntity("Success", HttpStatus.FOUND);
	} catch (Exception e) {
		return new ResponseEntity("Failed", HttpStatus.FOUND);
	}
}

}
