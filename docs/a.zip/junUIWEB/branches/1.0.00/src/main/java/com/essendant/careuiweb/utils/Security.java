package com.essendant.careuiweb.utils;

public class Security {

	public static String validateJWT(String jwt) {
		// add code here to validate jwt passed, update return value to return jwt key
		
		return null;
	}
}
