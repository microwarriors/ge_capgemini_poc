package com.essendant.careuiweb.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.essendant.careuiweb.annotations.ApiVersion;
import com.essendant.careuiweb.configuration.LoggingServiceInterface;
import com.essendant.careuiweb.consts.Version;
import com.essendant.careuiweb.service.OMSService;

@RestController
@ApiVersion(Version.ONE)
public class OrderController {
	@Autowired
	OMSService omsServiceImpl;
	@Autowired
	LoggingServiceInterface loggingService;	

	@RequestMapping("/order/create/{ponumber}")
    public ResponseEntity<?> createOrder(@RequestParam(value="ponumber", defaultValue="") String poNumber) {
		String accountNumber = "";
		
		omsServiceImpl.createOrder(accountNumber, poNumber);
		return new ResponseEntity("Order Created", HttpStatus.FOUND);
    }
	
	@RequestMapping("/order/update/{id}/{poNumber}")
    public ResponseEntity<?> updateOrder(@RequestParam(value="id", defaultValue="") String id, @RequestParam(value="ponumber", defaultValue="") String poNumber) {
		omsServiceImpl.updateOrder(id);
		return new ResponseEntity("Order Updated", HttpStatus.FOUND);
    }	
	
	@RequestMapping("/order/update/{id}")
    public ResponseEntity<?> cancelOrder(@RequestParam(value="id", defaultValue="") String id) {
		omsServiceImpl.cancelOrder(id);
		return new ResponseEntity("Order Cancelled", HttpStatus.FOUND);
    }
	
	@RequestMapping("/orderline/create/{id}/{itemnumber}/{quantity}")
    public ResponseEntity<?> createOrderLine(@RequestParam(value="id", defaultValue="") String id, @RequestParam(value="itemnumber", defaultValue="") String itemNumber, @RequestParam(value="quantity", defaultValue="0") String quantity) {
		omsServiceImpl.createOrderLine(id, itemNumber, quantity);
		return new ResponseEntity("Order Line Created", HttpStatus.FOUND);
    }	
	
	@RequestMapping("/orderline/update/{id}/{itemnumber}/{quantity}")
    public ResponseEntity<?> updateOrderLine(@RequestParam(value="id", defaultValue="") String id, @RequestParam(value="itemnumber", defaultValue="") String itemNumber, @RequestParam(value="quantity", defaultValue="0") String quantity) {
		omsServiceImpl.updateOrderLine(id, itemNumber, quantity);
		return new ResponseEntity("Order Line Updated", HttpStatus.FOUND);
    }	
	
	@RequestMapping("/orderline/cancel/{id}/{itemnumber}/{quantity}")
    public ResponseEntity<?> cancelOrderLine(@RequestParam(value="id", defaultValue="") String id, @RequestParam(value="itemnumber", defaultValue="") String itemNumber, @RequestParam(value="quantity", defaultValue="") String quantity) {
		omsServiceImpl.createOrderLine(id, itemNumber, quantity);
		return new ResponseEntity("Order Line Cancelled", HttpStatus.FOUND);
    }	
	
	@RequestMapping("/account/{accountnumber}")
    public ResponseEntity<?> lookupAccountInformation(@RequestParam(value="accountnumber", defaultValue="") String accountNumber) {
		omsServiceImpl.lookupAccountInformation(accountNumber);
        return new ResponseEntity("Item Pricing", HttpStatus.FOUND);
    }
	
	@RequestMapping("/item/pricing/{itemnumber}")
    public ResponseEntity<?> lookupItemPricing(@RequestParam(value="itemnumber", defaultValue="") String itemNumber) {
		omsServiceImpl.lookupItemPricing(itemNumber);
		return new ResponseEntity("Item Pricing", HttpStatus.FOUND);
    }	
	
	@RequestMapping("/item/stock/{itemnumber}")
    public ResponseEntity<?> lookupItemStock(@RequestParam(value="itemnumber", defaultValue="") String itemNumber) {
		omsServiceImpl.lookupItemStock(itemNumber);
		return new ResponseEntity("Item Stock", HttpStatus.FOUND);
    }	
	
	@RequestMapping(value="/", method=RequestMethod.POST)
	public ResponseEntity<Void> testPost(@RequestBody Object object, UriComponentsBuilder ucb){

		HttpHeaders headers = new HttpHeaders();
	    headers.add("1", "uno");
	    //headers.setLocation(ucb.path("/person/{id}").buildAndExpand(object.getId()).toUri());

	    return new ResponseEntity<>(headers, HttpStatus.CREATED);
	}
	
}
