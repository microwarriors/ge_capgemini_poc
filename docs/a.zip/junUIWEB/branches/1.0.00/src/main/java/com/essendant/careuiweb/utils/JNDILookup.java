package com.essendant.careuiweb.utils;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//added in 11.8.00 to provide generic way of doing JNDI lookups for resources
public class JNDILookup {
	private static final Logger LOGGER = LoggerFactory.getLogger(JNDILookup.class);
	
	public static <T> T LOOKUP(Class<T> clazz, String jndiName) {
		Object bean = null; 
		
		try {
			bean = LOOKUP(jndiName);
			return clazz.cast(PortableRemoteObject.narrow(bean, clazz));
		} catch (ClassCastException e) {
			return null;
		}
	}	
	public static Object LOOKUP(String jndiName) {
		Context context = null;
		
		try {
			context = new InitialContext();
			return context.lookup(jndiName);
		} catch (NamingException e) {
			e.printStackTrace();
			LOGGER.error("JNDILookup:LOOKUP(String jndiName) " + e.getMessage(), e);
			throw new IllegalStateException(e);
		} finally {
			try {
				context.close();
			} catch (NamingException e) {
				throw new IllegalStateException(e);
			}
		}
	}
}
