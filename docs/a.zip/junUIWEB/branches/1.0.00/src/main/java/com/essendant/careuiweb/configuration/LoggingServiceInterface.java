package com.essendant.careuiweb.configuration;

public interface LoggingServiceInterface {
	public void performLogging(String loggingLevel, String message, Throwable e);
}
