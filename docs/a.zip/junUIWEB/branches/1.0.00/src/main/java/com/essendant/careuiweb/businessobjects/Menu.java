package com.essendant.careuiweb.businessobjects;

import java.util.List;

import com.essendant.careuiweb.businessobjects.impl.MenuImpl;

public interface Menu {
	public void setLabel(String label);
	public String getLabel();
	
	public void setLink(String link);
	public String getLink();
	
	public List<MenuImpl> getNextLevalMenu();
}
