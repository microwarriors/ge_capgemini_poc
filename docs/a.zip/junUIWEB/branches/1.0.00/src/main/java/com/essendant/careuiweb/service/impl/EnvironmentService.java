package com.essendant.careuiweb.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
@PropertySource(value = { "classpath:com/essendant/careuiweb/props/appConfig.properties" })
public class EnvironmentService {

	@Autowired
	private Environment environment;

	public String getEnvPath(String module) {
		String envPath = "";
		envPath += environment.getProperty("com.essendant.careuiweb.config.scheme") + "://";
		envPath += environment.getProperty("com.essendant.careuiweb.config.hostname." + module);
		//envPath += environment.getProperty(":" + "com.essendant.careuiweb.config.port");
		return envPath;
	}

}
