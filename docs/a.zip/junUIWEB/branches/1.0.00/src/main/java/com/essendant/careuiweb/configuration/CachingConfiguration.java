package com.essendant.careuiweb.configuration;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.cache.Cache;
import org.springframework.cache.annotation.AnnotationCacheOperationSource;
import org.springframework.cache.interceptor.BeanFactoryCacheOperationSourceAdvisor;
import org.springframework.cache.interceptor.CacheInterceptor;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.essendant.careuiweb.utils.CareUIRuntime;
import com.ibm.websphere.objectgrid.spring.ObjectGridCache;
import com.ibm.websphere.objectgrid.spring.ObjectGridCatalogServiceDomainBean;
import com.ibm.websphere.objectgrid.spring.ObjectGridClientBean;
//import com.ussco.cache.spring.DefaultCacheKeyGenerator;

//Caching Configuration class will contain configuration for caching to be done during startup
//@Configuration
public class CachingConfiguration {
	private ObjectGridClientBean objectGridClientBean = new ObjectGridClientBean();
	private AnnotationCacheOperationSource annotationCacheOperationSource = new AnnotationCacheOperationSource();
	
	private ObjectGridCatalogServiceDomainBean objectGridCatalogServiceDomainBean() {
		ObjectGridCatalogServiceDomainBean objectGridCatalogServiceDomainBean = new ObjectGridCatalogServiceDomainBean();
		
		objectGridCatalogServiceDomainBean.setCatalogServiceEndpoints(CareUIRuntime.CACHE_CATALOG_HOST_PORT);
		return objectGridCatalogServiceDomainBean;
	}
	
	public ObjectGridClientBean objectGridClientBean() {
				
		this.objectGridClientBean.setCatalogServiceDomain(objectGridCatalogServiceDomainBean());
		return this.objectGridClientBean;
	}
			
		//@Bean
		public SimpleCacheManager simpleCacheManager() {
			SimpleCacheManager simpleCacheManager = new SimpleCacheManager();
			ObjectGridCache cache = null;
			Collection<Cache> cacheList = new ArrayList<Cache>();
			
			cache = new ObjectGridCache();
			cache.setName("com.ussco.cache.general");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.ussco.cache.users");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.ussco.cache.productmenu");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.ussco.cache.warehousepo");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.ussco.cache.facilities");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.ussco.cache.labelformat");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.ussco.cache.alertoutage");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.ussco.cache.general");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.ussco.cache.userprofile");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.ussco.cache.account.priceplans");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.essendant.cache.menu.product");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.essendant.cache.menu.orderinvoice");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);

			cache = new ObjectGridCache();
			cache.setName("com.essendant.cache.menu.customer");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.essendant.cache.menu.returncredit");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.essendant.cache.menu.account");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
			
			cache = new ObjectGridCache();
			cache.setName("com.essendant.cache.menu.dashboard");
			cache.setObjectGridClient(this.objectGridClientBean);
			cacheList.add(cache);
						
			simpleCacheManager.setCaches(cacheList);			
			return simpleCacheManager;
		}
	
		//@Bean
		public CacheInterceptor cacheInterceptor() {
			CacheInterceptor cacheInterceptor = new CacheInterceptor();
			
			cacheInterceptor.setCacheOperationSources(this.annotationCacheOperationSource);
			cacheInterceptor.setCacheManager(simpleCacheManager());
			return cacheInterceptor;
		}
				
		//@Bean
		public BeanFactoryCacheOperationSourceAdvisor beanFactoryCacheOperationSourceAdvisor() {
			BeanFactoryCacheOperationSourceAdvisor beanFactoryCacheOperationSourceAdvisor = new BeanFactoryCacheOperationSourceAdvisor();
			
			beanFactoryCacheOperationSourceAdvisor.setAdviceBeanName("cacheInterceptor");
			beanFactoryCacheOperationSourceAdvisor.setCacheOperationSource(this.annotationCacheOperationSource);
			return beanFactoryCacheOperationSourceAdvisor;
		}

		//@Bean
//		public DefaultCacheKeyGenerator defaultCacheKeyGenerator() {
//			return new DefaultCacheKeyGenerator();
//		}
}
