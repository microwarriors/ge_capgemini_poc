package com.essendant.careuiweb.businessobjects.impl;

import java.util.ArrayList;
import java.util.List;

import com.essendant.careuiweb.businessobjects.Menu;

public class MenuImpl implements Menu {
	private String label = null;
	private String link = null;
	private List<MenuImpl> NextLevalMenu = new ArrayList<MenuImpl>();

	public MenuImpl() {}
	
	public MenuImpl(String label, String link) {
		this.label = label;
		this.link = link;
	}
	
	@Override
	public void setLabel(String label) {
		this.label = label;
	}

	@Override
	public String getLabel() {
		return this.label;
	}

	@Override
	public void setLink(String link) {
		this.link = link;
	}

	@Override
	public String getLink() {
		return this.link;
	}

	@Override
	public List<MenuImpl> getNextLevalMenu() {
		return this.NextLevalMenu;
	}

}
