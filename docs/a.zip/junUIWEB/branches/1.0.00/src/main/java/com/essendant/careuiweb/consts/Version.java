package com.essendant.careuiweb.consts;

public class Version {
	public static final String ONE="1";
	public static final String TWO="2";
	public static final String THREE="3";
	public static final String PREFIX = "v";
}