package com.essendant.careuiweb.service;

import java.util.Map;

import com.essendant.careuiweb.businessobjects.Menu;
import com.ussco.ajax.ProductMenu;

public interface MenuNavigationService {

	public abstract Map<String, Menu> buildMockProductMenu();	
	//@Cacheable("com.essendant.cache.menu.product")
	public abstract ProductMenu buildProductMenu();
	
	public abstract Map<String, Menu> buildMockOrderInvoiceMenu();
	//@Cacheable("com.essendant.cache.menu.orderinvoice")
	public abstract ProductMenu buildOrderInvoiceMenu();

	public abstract Map<String, Menu> buildMockCustomerMenu();
	//@Cacheable("com.essendant.cache.menu.customer")
	public abstract ProductMenu buildCustomerMenu();
	
	public abstract Map<String, Menu> buildMockReturnCreditMenu();
	//@Cacheable("com.essendant.cache.menu.returncredit")
	public abstract ProductMenu buildReturnCreditMenu();
	
	public abstract Map<String, Menu> buildMockAccountMenu();
	//@Cacheable("com.essendant.cache.menu.account")
	public abstract ProductMenu buildAccountMenu();
		
	public abstract Map<String, Menu> buildMockDashboardMenu();
	//@Cacheable("com.essendant.cache.menu.dashboard")
	public abstract ProductMenu buildDashboardMenu();
	
	public abstract Map<String, Menu> buildMockFooterURL();
	public abstract ProductMenu buildFooterURL();
}