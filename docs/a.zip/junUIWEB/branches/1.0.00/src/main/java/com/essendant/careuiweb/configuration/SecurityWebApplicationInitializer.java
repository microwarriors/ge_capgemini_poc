/**
 *  This class is required to enable spring security for WAR.
 *  Since we are using annotation driven configuration, this class will be empty.
 */
package com.essendant.careuiweb.configuration;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * @author chavdas
 *
 */
public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {

	public SecurityWebApplicationInitializer() {
        super();
    }
}
