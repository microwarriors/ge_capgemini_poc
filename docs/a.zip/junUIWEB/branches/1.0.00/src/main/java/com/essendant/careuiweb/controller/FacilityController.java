package com.essendant.careuiweb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.essendant.careuiweb.annotations.ApiVersion;
import com.essendant.careuiweb.configuration.LoggingServiceInterface;
import com.essendant.careuiweb.consts.Version;

@RestController
@ApiVersion(Version.ONE)
public class FacilityController {
	@Autowired
	LoggingServiceInterface loggingService;	
	
	@RequestMapping("/facility")
    public ResponseEntity<?> lookupFacility() {
        return new ResponseEntity("Facility List", HttpStatus.FOUND);
    }
	
}
