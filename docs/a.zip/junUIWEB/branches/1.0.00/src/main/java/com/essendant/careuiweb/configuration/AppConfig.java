package com.essendant.careuiweb.configuration;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.mvc.method.annotation.AbstractJsonpResponseBodyAdvice;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.UrlBasedViewResolver;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class ReviewsConfig.
 */
@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "com.essendant.careuiweb.configuration, com.ussco.profile.service, org.springframework.security.saml, org.springframework.security.web")
//@ImportResource({ "classpath:com/essendant/careuiweb/${com.essendant.empower.security}"})
//@PropertySource({ "classpath:/com/essendant/careuiweb/properties/common.properties",
//	"classpath:/com/essendant/careuiweb/properties/${com.ussco.env.name}.properties"})
public class AppConfig extends WebMvcConfigurerAdapter {
	/**
	 * Jackson object mapper.
	 *
	 * @return the object mapper
	 */
	@Bean
	public ObjectMapper jacksonObjectMapper() {
		return new ObjectMapper();
	}

	/**
	 * Setup view resolver.
	 *
	 * @return the url based view resolver
	 */
	@Bean
	public UrlBasedViewResolver setupViewResolver() {
		final UrlBasedViewResolver resolver = new UrlBasedViewResolver();
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		resolver.setViewClass(JstlView.class);
		return resolver;
	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter
	 * #configureViewResolvers(org.springframework.web.servlet.config.annotation
	 * .ViewResolverRegistry)
	 */
	@Override
	public void configureViewResolvers(final ViewResolverRegistry registry) {
		final InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		viewResolver.setViewClass(JstlView.class);
		viewResolver.setPrefix("/resources/");
		viewResolver.setSuffix(".html");
		registry.viewResolver(viewResolver);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter
	 * #addResourceHandlers(org.springframework.web.servlet.config.annotation.
	 * ResourceHandlerRegistry)
	 */
	@Override
	public void addResourceHandlers(final ResourceHandlerRegistry registry) {
		/*
		 * registry.addResourceHandler("/resources/**", "/scripts/**",
		 * "/styles/**", "/fonts/**")
		 * .addResourceLocations("/dist/bower_components/", "/dist/scripts/",
		 * "/dist/styles/", "/dist/bower_components/bootstrap/fonts/**")
		 * .setCachePeriod(315569126);
		 */
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
	}

	/**
	 * Place holder configurer.
	 *
	 * @return the property placeholder configurer
	 */
	@Bean
	public static PropertyPlaceholderConfigurer placeHolderConfigurer() {
		final String envName = System.getProperty("com.essendant.env.name");

		final PropertyPlaceholderConfigurer ppc = new PropertyPlaceholderConfigurer();

		Resource[] resources = null;

		if (envName != null) {
			resources = new ClassPathResource[] {
					new ClassPathResource("com/essendant/careuiweb/properties/common.properties"),
					new ClassPathResource("com/essendant/careuiweb/properties/" + envName + ".properties") };
		} else {
			resources = new ClassPathResource[] {
					new ClassPathResource("com/essendant/careuiweb/properties/common.properties")};
		}

		ppc.setLocations(resources);
		ppc.setIgnoreUnresolvablePlaceholders(true);
		ppc.setIgnoreResourceNotFound(true);
		return ppc;
	}

	/**
	 * The Class JsonpAdvice.
	 */
	@ControllerAdvice
	private static class JsonpAdvice extends AbstractJsonpResponseBodyAdvice {

		/**
		 * Instantiates a new jsonp advice.
		 */
		public JsonpAdvice() {
			super("callback");
		}
	}

	
}
