package com.essendant.careuiweb.service;

public interface OMSService {

	public abstract void createOrder(String account, String poNumber);
	public abstract void updateOrder(String orderId);
	public abstract void cancelOrder(String orderId);
	public abstract void createOrderLine(String orderId, String itemNumber, String quantity);
	public abstract void updateOrderLine(String orderId, String itemNumber, String quantity);
	public abstract void cancelOrderLine(String orderId);
	public abstract void lookupOrder(String orderId);
	public abstract void lookupAccountInformation(String accountNumber);
	public abstract void lookupItemPricing(String itemNumber);
	public abstract void lookupItemStock(String itemNumber);
}
