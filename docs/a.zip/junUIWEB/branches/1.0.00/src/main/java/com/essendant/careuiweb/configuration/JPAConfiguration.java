package com.essendant.careuiweb.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

//JPA Configuration class will contain configuration for datasources, jpa entity manager factory, transaction manager
@Configuration
public class JPAConfiguration {

}
