package com.essendant.careuiweb.configuration;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class LoggingService implements LoggingServiceInterface {
	@Autowired
	Logger logger;
	
	@Override
	public void performLogging(String loggingLevel, String message, Throwable e) {		
		if (("TRACE").equals(loggingLevel)) {
			if (e == null) {
				logger.trace(message);
			} else {
				logger.trace(message, e);
			}
		} else if (("DEBUG").equals(loggingLevel)) {
			if (e == null) {
				logger.debug(message);
			} else {
				logger.debug(message, e);
			}			
		} else if (("INFO").equals(loggingLevel)) {
			if (e == null) {
				logger.info(message);
			} else {
				logger.info(message, e);
			}			
		} else if (("ERROR").equals(loggingLevel)) {
			if (e == null) {
				logger.error(message);
			} else {
				logger.error(message, e);
			}			
		}
	}

}
