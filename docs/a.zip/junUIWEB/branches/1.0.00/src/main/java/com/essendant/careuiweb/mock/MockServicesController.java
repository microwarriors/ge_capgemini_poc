package com.essendant.careuiweb.mock;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.essendant.careuiweb.annotations.ApiVersion;
import com.essendant.careuiweb.consts.Version;
import com.essendant.careuiweb.service.impl.EnvironmentService;
import com.essendant.careuiweb.utils.RequestObject;

@RestController
@ApiVersion(Version.ONE)
public class MockServicesController {

	@Autowired
    private EnvironmentService environment;
	
	@Autowired
	MockService mockService;
	
	@ApiVersion({Version.ONE})
	@PostMapping(value="/getNavMenuItems", produces="application/json")
	public ResponseEntity<String> getNavMenuItems() throws IOException {
		String str = mockService.getNavMenuItems();
		return new ResponseEntity<>(str, HttpStatus.OK);
	}
	
	@ApiVersion({Version.ONE})
	@PostMapping(value="/getCountries", produces="application/json")
	public ResponseEntity<String> getCountries() throws IOException {
		String str = mockService.getCountries();
		return new ResponseEntity<>(str, HttpStatus.OK);
	}
	
	@ApiVersion({Version.ONE})
	@PostMapping(value="/getCurrentAccount", produces="application/json")
	public ResponseEntity<String> getCurrentAccount() throws IOException {
		String str = mockService.getCurrentAccount();
		return new ResponseEntity<>(str, HttpStatus.OK);
	}
	
	@ApiVersion({Version.ONE})
	@PostMapping(value="/getShipToAccount/{accountId}", produces="application/json")
	public ResponseEntity<String> getShipToAccount(@PathVariable("accountId") String accountId) throws IOException {
		String str = mockService.getShipToAccount();
		return new ResponseEntity<>(str, HttpStatus.OK);
	}
	
}
