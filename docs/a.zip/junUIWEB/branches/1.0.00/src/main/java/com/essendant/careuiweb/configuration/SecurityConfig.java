/**
 * This class is required to enable spring security configuration.
 * Since we are using annotation driven configuration, this class will be empty.
 * This class is configured in ReviewsInitializer
 */
package com.essendant.careuiweb.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.saml.SAMLBootstrap;

/**
 * @author chavdas
 *
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter  {
	 
	@Bean
    public static SAMLBootstrap SAMLBootstrap() {
        return new AppSAMLBootstrap();
    }
	
}
