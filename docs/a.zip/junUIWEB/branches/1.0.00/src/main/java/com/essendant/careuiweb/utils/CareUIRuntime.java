package com.essendant.careuiweb.utils;

public class CareUIRuntime {
	public static String ESB_USER_ID = "";
	public static String ESB_PASSWORD = "";
	public static String SMARTSEARCH_USER_ID = "";
	public static String SMARTSEARCH_PASSWORD = "";
	public static String SOLR_INVOICE_URL = "";
	public static String SOLR_ORDER_URL = "";
	public static String ESB_WSDL_URL = "";
	public static String SMARTSEARCH_WSDL_URL = "";
	public static String RUNTIME_ENVIRONMENT = null;	// ie: local, dev, qas, ppd, prd
	public static String CLEARANCE_FEATURE = "";
	public static String SMARTSEARCH_TYPEAHEAD_URL = "";
	public static String SOLUTIONCENTRAL_URL = "";
	public static String ANALYTICS = "";
	public static final String EWS_OPERATIONS_CONTEXT = "operations";
	public static final String EWS_PROFILE_CONTEXT = "profile";
	public static final String EWS_PRICINGDASHBOARD_CONTEXT = "pricingdashboard";
	public static final String EWS_CREDITDASHBOARD_CONTEXT = "creditdeductiondashboard";
	public static final String EWS_CAREUI_CONTEXT = "care";
	public static String CACHE_CATALOG_HOST_PORT = "";
	//public static String SECURITY_MODE = "";
	public static String HOST_NAME = "";
	
	{
		READAPPLICATIONPROPERTIES();
	}

	
	public static void READAPPLICATIONPROPERTIES() {
		CareUIRuntime.ESB_USER_ID = (String) JNDILookup.LOOKUP("com.essendant.esb.service.userid");
		CareUIRuntime.ESB_PASSWORD = (String) JNDILookup.LOOKUP("com.essendant.esb.service.password");
		CareUIRuntime.SMARTSEARCH_USER_ID = (String) JNDILookup.LOOKUP("com.essendant.smartsearch.service.userid");
		CareUIRuntime.SMARTSEARCH_PASSWORD = (String) JNDILookup.LOOKUP("com.essendant.smartsearch.service.password");
		CareUIRuntime.SOLR_INVOICE_URL = (String) JNDILookup.LOOKUP("com.essendant.empower.solr.invoice.url");
		CareUIRuntime.SOLR_ORDER_URL = (String) JNDILookup.LOOKUP("com.essendant.empower.solr.order.url");
		CareUIRuntime.ESB_WSDL_URL = (String) JNDILookup.LOOKUP("com.essendant.empower.esb.wsdl.uri");
		CareUIRuntime.SMARTSEARCH_WSDL_URL = (String) JNDILookup.LOOKUP("com.essendant.empower.smartsearch.wsdl.uri");
		CareUIRuntime.RUNTIME_ENVIRONMENT = System.getProperty("com.ussco.env.name");
		CareUIRuntime.CLEARANCE_FEATURE = (String) JNDILookup.LOOKUP("com.essendant.clearance.feature");
		CareUIRuntime.SMARTSEARCH_TYPEAHEAD_URL = (String) JNDILookup.LOOKUP("com.essendant.smartsearchtypeahead.url");
		CareUIRuntime.SOLUTIONCENTRAL_URL = (String) JNDILookup.LOOKUP("com.essendant.solutionscentral.url");
		CareUIRuntime.ANALYTICS = (String) JNDILookup.LOOKUP("com.essendant.ecatalog.analytics");	
		CareUIRuntime.CACHE_CATALOG_HOST_PORT =  System.getProperty("com.ussco.wxs.catalogHostPort");
		//CareUIRuntime.SECURITY_MODE = (String) JNDILookup.LOOKUP("com.essendant.empower.security");
		CareUIRuntime.HOST_NAME = System.getProperty("com.essendant.config.hostname");		
	}
}
