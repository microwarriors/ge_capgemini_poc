package com.essendant.careuiweb.configuration;

import org.apache.log4j.DailyRollingFileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

//Log4j Configuration class will contain configuration for Log4j logging
@Configuration
//@EnableWebMvc
@ComponentScan("com.essendant.careuiweb.controller")
public class Log4jConfiguration {

	@Profile({"localhost", "dev2", "qas2", "tst1", "ppd2" })
	@Bean Logger appLogger() {
		// creates pattern layout
        PatternLayout layout = new PatternLayout();
        String conversionPattern = "[%p] %d %c %M - %m%n";
        layout.setConversionPattern(conversionPattern);
 
        // creates daily rolling file appender
        DailyRollingFileAppender rollingAppender = new DailyRollingFileAppender();
        rollingAppender.setFile(System.getProperty("com.ussco.application.log.root") + "/careweb/careweb.log");
        rollingAppender.setDatePattern("'.'yyyy-MM-dd");
        rollingAppender.setLayout(layout);
        rollingAppender.activateOptions();
 
        // configures the root logger
        Logger rootLogger = Logger.getRootLogger();
		rollingAppender.setThreshold(Level.ALL);        
        rootLogger.setLevel(Level.DEBUG);
        rootLogger.addAppender(rollingAppender);
 
        // creates a custom logger and log messages
        Logger logger = Logger.getLogger(LoggingService.class);
        logger.info("Log4jConfiguration:appLogger Log4j intialized for Care Web application logging to " + System.getProperty("com.ussco.application.log.root") + "/careweb/careweb.log");
        return logger;
	}
	
	@Profile({"prd1"})
	@Bean Logger appProductionLogger() {
		// creates pattern layout
        PatternLayout layout = new PatternLayout();
        String conversionPattern = "[%p] %d %c %M - %m%n";
        layout.setConversionPattern(conversionPattern);
 
        // creates daily rolling file appender
        DailyRollingFileAppender rollingAppender = new DailyRollingFileAppender();
        rollingAppender.setFile(System.getProperty("com.ussco.application.log.root") + "/careweb/careweb.log");
        rollingAppender.setDatePattern("'.'yyyy-MM-dd");
        rollingAppender.setLayout(layout);
        rollingAppender.activateOptions();
 
        // configures the root logger
        Logger rootLogger = Logger.getRootLogger();
		rollingAppender.setThreshold(Level.INFO);        
        rootLogger.setLevel(Level.DEBUG);
        rootLogger.addAppender(rollingAppender);
 
        // creates a custom logger and log messages
        Logger logger = Logger.getLogger(LoggingService.class);
        logger.info("Log4jConfiguration:appLogger Log4j intialized for Care Web application logging to " + System.getProperty("com.ussco.application.log.root") + "/careweb/careweb.log");
        return logger;
	}	
	
//	@Bean
//	public FileAppender fileAppender() {
//		DailyRollingFileAppender fileAppender = new DailyRollingFileAppender();
//		String environment = System.getProperty("com.ussco.env.name");
//		
//        // creates pattern layout
//        PatternLayout layout = new PatternLayout();
//        String conversionPattern = "[%p] %d %c %M - %m%n";
//        layout.setConversionPattern(conversionPattern);
//        
//		fileAppender.setFile(System.getProperty("com.ussco.application.log.root") + "/careweb/careweb.log");
//
//		fileAppender.setThreshold(Level.ALL);
//		fileAppender.setAppend(true);
//		fileAppender.setDatePattern("'.'yyyy-MM-dd");
//		fileAppender.setLayout(layout);		
//		fileAppender.activateOptions();						
//		
//		System.out.println("file appender setup");
//		return fileAppender;
//	}
	
//	@Bean 
//	public Logger registerLogger() {
//		Logger logger = Logger.getLogger(LoggingService.class);
//		
//		System.out.println("Registering Logger for Care UI Web Application");
//		logger.addAppender(fileAppender());
//		logger.debug("Registering Logger for Care UI Web Application");
//		return logger;
//	}
}
