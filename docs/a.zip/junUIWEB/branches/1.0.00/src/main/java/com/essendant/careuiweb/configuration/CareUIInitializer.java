package com.essendant.careuiweb.configuration;


public class CareUIInitializer { // extends AbstractAnnotationConfigDispatcherServletInitializer {
//	@Override
//    protected Class<?>[] getRootConfigClasses() {
//        return new Class[] { Log4jConfiguration.class, CareUIConfiguration.class, CoreConfiguration.class, JPAConfiguration.class, SecurityConfiguration.class, CachingConfiguration.class };
//    }
//  
//    @Override
//    protected Class<?>[] getServletConfigClasses() {
//        return null;
//    }
//  
//    @Override
//    protected String[] getServletMappings() {
//        return new String[] { "/" };
//    }
}
