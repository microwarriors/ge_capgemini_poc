package com.essendant.careuiweb.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.essendant.careuiweb.businessobjects.Menu;
import com.essendant.careuiweb.businessobjects.impl.MenuImpl;
import com.essendant.careuiweb.configuration.LoggingServiceInterface;
import com.essendant.careuiweb.service.MenuNavigationService;
import com.essendant.careuiweb.utils.CareUIRuntime;
import com.ussco.ajax.ProductMenu;
import com.ussco.ajax.ProductMenuCategory;
import com.ussco.ajax.impl.ProductMenuCategoryImpl;
import com.ussco.ajax.impl.ProductMenuImpl;
import com.ussco.profile.util.UnitedUserProfileUtils;
import com.ussco.web.ajax.service.ProductMenuOptionService;
import com.ussco.web.enums.SuppliesFinderLevel;
import com.ussco.web.service.util.InternalUserUtils;


@Scope("prototype")
@Service
public class MenuNavigationServiceImpl implements MenuNavigationService {
	@Autowired
	LoggingServiceInterface loggingService;
    /**
     * ProductMenuOptionService
     */
    protected ProductMenuOptionService productMenuOptionService;       
    
	@Override
	public Map<String, Menu> buildMockProductMenu() {

		return createProductMockupMenu();
	}	
	
	@Override
	public ProductMenu buildProductMenu() {
		return createProductMenu();
	}

	@Override
	public Map<String, Menu> buildMockOrderInvoiceMenu() {
		
		return createOrderInvoiceMockupMenu();
	}

	@Override
	public ProductMenu buildOrderInvoiceMenu() {
		return null;
		//return createInvoiceMenu();
	}	
	
	@Override
	public Map<String, Menu> buildMockCustomerMenu() {
		
		return createCustomerMockupMenu();
	}
	
	@Override
	public ProductMenu buildCustomerMenu() {
		return null;
		//return createCustomerMenu();
	}	

	@Override
	public Map<String, Menu> buildMockReturnCreditMenu() {
		
		return createReturnMockupMenu();
	}
	
	@Override
	public ProductMenu buildReturnCreditMenu() {
		return null;
		//return createReturnMenu();
	}	

	@Override
	public Map<String, Menu> buildMockAccountMenu() {
		
		return createAccountMockupMenu();
	}

	@Override
	public ProductMenu buildAccountMenu() {
		
		return null;
		//return createAccountMenu();
	}
	
	
	@Override
	public Map<String, Menu> buildMockDashboardMenu() {
		
		return createDashboardMockupMenu();
	}
	
	@Override
	public ProductMenu buildDashboardMenu() {
		return null;
		//return createDashboardMenu();
	}	
	
	@Override
	public Map<String, Menu> buildMockFooterURL() {
		Map<String, Menu> menuMap = new HashMap<String, Menu>();
		Menu menu = null;
		
		menu = new MenuImpl("URL", CareUIRuntime.SOLUTIONCENTRAL_URL);
		menuMap.put("1", menu);
		return menuMap;
	}
	
	@Override
	public ProductMenu buildFooterURL() {
		Map<String, ProductMenuCategory> menuMap = new HashMap<String, ProductMenuCategory>();
		ProductMenuCategory menuCategory = new ProductMenuCategoryImpl("URL", CareUIRuntime.SOLUTIONCENTRAL_URL, "");
		ProductMenu menu = new ProductMenuImpl();
		
		return menu;
	}	

	
	private Map<String, Menu> createProductMockupMenu() {
		Map<String, Menu> menuMap = new HashMap<String, Menu>();
		Menu menu = null;
		
		menu = new MenuImpl("Office", "");
		menu.getNextLevalMenu().add(new MenuImpl("Batteries & Electrical Supplies", "https://ppd2-empowercentral.ussco.com/operations/page/list?c=176"));
		menu.getNextLevalMenu().add(new MenuImpl("Breakroom Supplies", "https://ppd2-empowercentral.ussco.com/operations/page/list?c=178"));
		menuMap.put("1", menu);
		
		menu = new MenuImpl("Technology", "");
		menu.getNextLevalMenu().add(new MenuImpl("Calculators", "https://ppd2-empowercentral.ussco.com/operations/page/list?c=221"));
		menu.getNextLevalMenu().add(new MenuImpl("Computer Software", "https://ppd2-empowercentral.ussco.com/operations/page/list?c=226"));
		menuMap.put("2", menu);
		
		return menuMap;
	}
	
	private ProductMenu createProductMenu() {
    	Map<SuppliesFinderLevel, List<ProductMenuCategoryImpl>> suppliesMap = null;
    	ProductMenuCategory menuCategory = null;
    	String activeAccountNumber = "";    	
    	
        // getting the product menu for the request
        ProductMenu productMenu = this.productMenuOptionService.getProductMenuOptionsFromAccounts(CareUIRuntime.HOST_NAME, UnitedUserProfileUtils.getActiveAccounts());
        
        if (("Y").equalsIgnoreCase(com.ussco.businessservices.web.util.DataConstants.CLEARANCEFEATURE()) || ("").equalsIgnoreCase(com.ussco.businessservices.web.util.DataConstants.CLEARANCEFEATURE())) {
    		// Get selected ship to account
            //Account internalSoldTo=InternalUserUtils.getInternalUserAccount();
            if (InternalUserUtils.isInternalUser()) {	// internal user use sold to account number for last selected account
            	activeAccountNumber = UnitedUserProfileUtils.getActiveAccounts().get(0).getAccountNumber();	// internalSoldTo.getShipToAccountNumber();
            } else {	// external user
            	activeAccountNumber = UnitedUserProfileUtils.getActiveAccounts().get(0).getAccountNumber();
            	/*
                UserProfile userProfile = UnitedUserProfileUtils.getUserProfile();
    	        if (userProfile.getLastSelectedAccountGroup() != null) {
    	        	activeAccountNumber = userProfile.getLastSelectedAccountGroup().getDefaultAccount().getAccount();
    	        } else {
    	        	activeAccountNumber = userProfile.getLastSelectedAccountNumber();
    	        }
    	        */
            }        	
        	
        	menuCategory = this.productMenuOptionService.getClearanceMenuOptionItem(CareUIRuntime.HOST_NAME, UnitedUserProfileUtils.getActiveAccounts(), activeAccountNumber);
        	if (menuCategory != null) {
        		productMenu.getProductCategories().add(menuCategory);
        	}
        }
        
        suppliesMap = this.productMenuOptionService.getSuppliesFinderBrandsMenuOptionItem(CareUIRuntime.HOST_NAME, UnitedUserProfileUtils.getActiveAccounts());
        productMenu.getTopSuppliesFinderCategories().addAll(suppliesMap.get(SuppliesFinderLevel.HIGHLIGHTED));
        productMenu.getMoreSuppliesFinderCategories().addAll(suppliesMap.get(SuppliesFinderLevel.TOP));
        return productMenu;
	}
	
	private Map<String, Menu> createOrderInvoiceMockupMenu() {
		Map<String, Menu> menuMap = new HashMap<String, Menu>();
		Menu menu = null;
		
		menu = new MenuImpl("Create New Order", "");
		menu.getNextLevalMenu().add(new MenuImpl("Ship To Us", "https://dev2-empowercentral.ussco.com/operations/page/new-ship-to-us-order"));
		menu.getNextLevalMenu().add(new MenuImpl("Wrap and Label", "https://dev2-empowercentral.ussco.com/operations/page/new-wrap-and-label-order"));
		menu.getNextLevalMenu().add(new MenuImpl("Dropship", "https://dev2-empowercentral.ussco.com/operations/page/new-drop-ship-order"));
		menu.getNextLevalMenu().add(new MenuImpl("Will Call", "https://dev2-empowercentral.ussco.com/operations/page/new-will-call-order"));		
		menuMap.put("1", menu);
		
		menu = new MenuImpl("Recent Orders", "https://dev2-empowercentral.ussco.com/operations/page/list-order");
		menuMap.put("2", menu);
		
		menu = new MenuImpl("View OMS Orders", "https://dev2-empowercentral.ussco.com/operations/page/list-unifiedorder");
		menuMap.put("3", menu);		
		
		menu = new MenuImpl("Manage Backorders", "https://dev2-empowercentral.ussco.com/operations/page/list-backorder");
		menuMap.put("4", menu);		
		
		menu = new MenuImpl("Invoice & Purchase History", "https://dev2-empowercentral.ussco.com/operations/page/list-invoice");
		menuMap.put("5", menu);		
		
		return menuMap;
	}	
	
	private Map<String, Menu> createReturnMockupMenu() {
		Map<String, Menu> menuMap = new HashMap<String, Menu>();
		Menu menu = null;
		
		menu = new MenuImpl("Returns & Credits", "");
		menu.getNextLevalMenu().add(new MenuImpl("Add Items to Today's Return", "https://dev2-empowercentral.ussco.com/operations/page/returns-select"));		
		menuMap.put("1", menu);
		
		menu = new MenuImpl("Create New Return", "https://dev2-empowercentral.ussco.com/operations/page/returns-new");
		menuMap.put("2", menu);
		
		menu = new MenuImpl("View Return & Credit History", "https://dev2-empowercentral.ussco.com/operations/page/returns-find");
		menuMap.put("3", menu);		
				
		return menuMap;
	}	
	
	private Map<String, Menu> createCustomerMockupMenu() {
		Map<String, Menu> menuMap = new HashMap<String, Menu>();
		Menu menu = null;
		
		menu = new MenuImpl("Customers", "https://dev2-empowercentral.ussco.com/profile/page/list-addressbook");		
		menuMap.put("1", menu);				
		
		return menuMap;
	}	
	
	private Map<String, Menu> createAccountMockupMenu() {
		Map<String, Menu> menuMap = new HashMap<String, Menu>();
		Menu menu = null;
		
		menu = new MenuImpl("Account", "");
		menu.getNextLevalMenu().add(new MenuImpl("Manage Accounts", "https://dev2-empowercentral.ussco.com/profile/page/list-authorized-ship-to-account"));		
		menuMap.put("1", menu);
		
		menu = new MenuImpl("Volume Rebate", "https://dev2-empowercentral.ussco.com/operations/page/vcd");
		menuMap.put("2", menu);
				
		return menuMap;
	}	
	
	private Map<String, Menu> createDashboardMockupMenu() {
		Map<String, Menu> menuMap = new HashMap<String, Menu>();
		Menu menu = null;
		
		menu = new MenuImpl("Dashboard", "");
		menu.getNextLevalMenu().add(new MenuImpl("Claim Dashboard", ""));
		menu.getNextLevalMenu().get(0).getNextLevalMenu().add(new MenuImpl("Claim Research Queue", "https://dev2-empowercentral.ussco.com/creditdeductiondashboard/page/claim-research-queue"));
		menu.getNextLevalMenu().get(0).getNextLevalMenu().add(new MenuImpl("Claim Approval Queue", "https://dev2-empowercentral.ussco.com/creditdeductiondashboard/page/claim-approval-queue"));
		menu.getNextLevalMenu().get(0).getNextLevalMenu().add(new MenuImpl("Claim Rules", "https://dev2-empowercentral.ussco.com/creditdeductiondashboard/page/ruleListing"));

		menu.getNextLevalMenu().add(new MenuImpl("Pricing Dashboard", ""));
		menu.getNextLevalMenu().get(1).getNextLevalMenu().add(new MenuImpl("Item Entry", "https://dev2-empowercentral.ussco.com/pricingdashboard/page/item-entry"));
		menu.getNextLevalMenu().get(1).getNextLevalMenu().add(new MenuImpl("Submission Queue", "https://dev2-empowercentral.ussco.com/pricingdashboard/page/submissionQueue"));
		menu.getNextLevalMenu().get(1).getNextLevalMenu().add(new MenuImpl("Price History", "https://dev2-empowercentral.ussco.com/pricingdashboard/page/submissionQueue"));
		menu.getNextLevalMenu().get(1).getNextLevalMenu().add(new MenuImpl("Price Rules", "https://dev2-empowercentral.ussco.com/pricingdashboard/page/ruleListing"));
		menu.getNextLevalMenu().get(1).getNextLevalMenu().add(new MenuImpl("Price Approval Queue", "https://dev2-empowercentral.ussco.com/pricingdashboard/page/approvalQueue"));		
		menuMap.put("1", menu);
						
		return menuMap;
	}	
	
	
    /**
     * Returns ProductMenuOptionService
     * 
     * @return ProductMenuOptionService.
     */
    public ProductMenuOptionService getProductMenuOptionService() {
        return productMenuOptionService;
    }

    /**
     * Sets the ProductMenuOptionService.
     */
    @Resource
    public void setProductMenuOptionService(ProductMenuOptionService productMenuOptionService) {
        this.productMenuOptionService = productMenuOptionService;
    }
			
}
