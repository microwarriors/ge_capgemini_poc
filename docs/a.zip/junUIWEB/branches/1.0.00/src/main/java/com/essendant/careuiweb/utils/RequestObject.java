package com.essendant.careuiweb.utils;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class RequestObject {

	private String accountId;
	private String userId;
	private String orderId;
	private String page;
	private String[]  params;

	public RequestObject() {
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String[] getParams() {
		return params;
	}

	@JsonIgnore
	public void setParams(String[] params) {
		this.params = params;
	}

		
}
