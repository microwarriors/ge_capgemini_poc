package com.essendant.careuiweb.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.essendant.careuiweb.annotations.ApiVersion;
import com.essendant.careuiweb.configuration.LoggingServiceInterface;
import com.essendant.careuiweb.consts.Version;
import com.essendant.careuiweb.service.impl.EnvironmentService;
import com.essendant.careuiweb.utils.RequestObject;

@RestController
@ApiVersion(Version.ONE)
public class RedirectController {
	@Autowired
	LoggingServiceInterface loggingService;
	@Autowired
    private EnvironmentService environment;
	
	//This controller method is called from Empower, This method will redirect to Care UI Client
	@GetMapping(value="/redirect")
	public void testRedirect(HttpServletResponse response) throws IOException {
		response.sendRedirect(environment.getEnvPath("client") + "/care");
	}
	
	//This controller method is called from Care UI Client, This method will redirect to Empower
	@PostMapping(value="/redirectEmpower")
	public void redirectToEmpower(HttpServletResponse response) throws IOException {
		response.sendRedirect(environment.getEnvPath("empower") + "/operations/page/list-order");
	}
	
	//This controller method is called from Empower, This method will redirect to Care UI Client
	@GetMapping(value="/redirectWith")
	public void testRedirectWithParams(@RequestParam(value="orderType", defaultValue="") String orderType, HttpServletResponse response) throws IOException {		
		response.sendRedirect(environment.getEnvPath("client") + "/care");
	}
	
	//This controller method is called from Care UI Client, This method will redirect to Empower
	@PostMapping(value="/redirectEmpowerWith", consumes="application/json")
	public void redirectToEmpowerWithParams(HttpServletResponse response, @RequestBody RequestObject req) throws IOException {
		response.sendRedirect(environment.getEnvPath("empower") + "/operations/page/view-ship-to-us-order");
		return;
	}
	
	@ApiVersion({Version.ONE, Version.TWO})
	@GetMapping(value="/test")
	public ResponseEntity<?> testService(HttpServletRequest request) throws IOException {
		loggingService.performLogging("DEBUG", "RedirectController:test test logging", null);
		return new ResponseEntity("Test Successful", HttpStatus.FOUND);
	}
	
}
